def hi():
    print("HI")